// Henrybankki Firebase-konfiguraatio
const firebaseConfig = {
  apiKey: "AIzaSyC_67n4Sf1wqjdc2tSZzzhYK3ZbrizF8nQ",
  authDomain: "henrybankki.firebaseapp.com",
  projectId: "henrybankki",
  storageBucket: "henrybankki.firebasestorage.app",
  messagingSenderId: "597512229806",
  appId: "1:597512229806:web:6a4f5c304ff355f11eee3f",
  measurementId: "G-4PV8ES2R3X"
};

firebase.initializeApp(firebaseConfig);
